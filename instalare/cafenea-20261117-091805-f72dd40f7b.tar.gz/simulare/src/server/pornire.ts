// Pornește serverul real (rutele și serviciile din server/src) în browser, pe PGlite, cu rețeaua
// demo încărcată dintr-o arhivă. Tot ce face simularea trece prin același cod ca în producție;
// doar terminalul PAX și rețeaua sunt înlocuite.
import { PGlite, types } from '@electric-sql/pglite';
import urlWasm from 'pglite-dist/pglite.wasm?url';
import { bazaRaspunde, dinPglite, type Db } from '../../../server/src/db-comun';
import { magistrala, type Notificare } from '../../../server/src/magistrala';
import { ruteAdmin } from '../../../server/src/rute/admin';
import { rutePOS } from '../../../server/src/rute/pos';
import * as acces from '../../../server/src/servicii/acces';
import { ClientPOSLink } from '../../../server/src/servicii/poslink';
import { citesteSetare, scrieSetare } from '../../../server/src/servicii/setari';
import { folosesteClientPOSLink } from '../../../server/src/servicii/terminal';
import { CHEIE_SIMULARE } from '../constante';
import { RuterSim, type CerereSim, type RaspunsSim } from './ruter';
import { TerminalSimulat } from './terminal-simulat';

export interface TabletaSim {
  token: string;
  dispozitiv: { id: number; nume: string; locatie_id: number };
}

export interface ServerSim {
  db: Db;
  ruter: RuterSim;
  terminal: TerminalSimulat;
  tokenAdmin: string;
  centru: TabletaSim;
  botanica: TabletaSim;
  /** true când baza tocmai a fost creată din arhivă (la previzualizare: prima deschidere pe dispozitiv). */
  proaspat: boolean;
  /** Fluxul de notificări (SSE) pentru un bilet; întoarce funcția de oprire sau null dacă biletul nu e valid. */
  flux(bilet: string, laMesaj: (date: string) => void): (() => void) | null;
}

export interface OptiuniServer {
  /** Arhiva cu datele de pornire, lângă scriptul paginii (implicit rețeaua demo cu istoric). */
  arhiva?: string;
  /** Baza se păstrează în browser (IndexedDB) sub acest nume: ce se vinde rămâne și după închidere. */
  persistenta?: string;
  /** Terminalul PAX simulat; fără el tableta lucrează cu terminalul separat (fără legătură). */
  terminalSimulat?: boolean;
}

export interface Progres {
  faza: string;
  procent: number;
}

async function descarca(url: string, laOcteti: (n: number, total: number) => void): Promise<Uint8Array<ArrayBuffer>> {
  const r = await fetch(url);
  if (!r.ok || !r.body) throw new Error(`Nu s-a putut descărca ${url} (${r.status})`);
  const total = Number(r.headers.get('content-length')) || 0;
  const bucati: Uint8Array[] = [];
  let primiti = 0;
  const cititor = r.body.getReader();
  for (;;) {
    const { done, value } = await cititor.read();
    if (done) break;
    bucati.push(value);
    primiti += value.length;
    laOcteti(primiti, total);
  }
  const tot = new Uint8Array(primiti);
  let poz = 0;
  for (const b of bucati) {
    tot.set(b, poz);
    poz += b.length;
  }
  return tot;
}

/** Datele binare vin ca text base64 (gazda servește doar tipuri web). */
function dinBase64(octeti: Uint8Array<ArrayBuffer>): Uint8Array<ArrayBuffer> {
  const binar = atob(new TextDecoder().decode(octeti).trim());
  const rez = new Uint8Array(binar.length);
  for (let i = 0; i < binar.length; i++) rez[i] = binar.charCodeAt(i);
  return rez;
}

async function dezarhiveaza(gz: Uint8Array<ArrayBuffer>): Promise<Uint8Array<ArrayBuffer>> {
  return new Uint8Array(await new Response(new Blob([gz]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
}

// Fișierele de date stau lângă scriptul paginii (assets/).
const bazaModul = import.meta.url;

const ziLocala = (d: Date) => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Chisinau' }).format(d);

// Migrațiile serverului, incluse în pagină: o arhivă de date generată cu o versiune mai veche a
// schemei primește la pornire ce îi lipsește, exact ca serverul (server/src/db.ts).
const MIGRARI = import.meta.glob<string>('../../../server/migrari/*.sql', { query: '?raw', import: 'default', eager: true });

async function aplicaMigrari(db: Db) {
  await db.exec('CREATE TABLE IF NOT EXISTS schema_migrari (nume text PRIMARY KEY, aplicata_la timestamptz NOT NULL DEFAULT now())');
  const aplicate = new Set((await db.query<{ nume: string }>('SELECT nume FROM schema_migrari')).map((r) => r.nume));
  for (const [cale, sql] of Object.entries(MIGRARI).sort(([a], [b]) => a.localeCompare(b))) {
    const nume = cale.split('/').pop()!;
    if (aplicate.has(nume)) continue;
    await db.tx(async (t) => {
      await t.exec(sql);
      await t.query('INSERT INTO schema_migrari (nume) VALUES ($1)', [nume]);
    });
  }
}

/** Mută tot istoricul cu un număr întreg de zile, ca ultima zi din arhivă să devină ieri. */
async function aduceIstoriculLaZi(db: Db) {
  const { generat_pentru } = await citesteSetare(db, CHEIE_SIMULARE, { generat_pentru: '' });
  if (!generat_pentru) return;
  const azi = ziLocala(new Date());
  const zile = Math.round((Date.parse(azi) - Date.parse(generat_pentru)) / 86_400_000);
  if (!zile) return;
  const coloane = await db.query<{ tabel: string; coloana: string }>(
    `SELECT c.table_name AS tabel, c.column_name AS coloana
       FROM information_schema.columns c
       JOIN information_schema.tables t ON t.table_schema = c.table_schema AND t.table_name = c.table_name
      WHERE c.table_schema = 'public' AND t.table_type = 'BASE TABLE' AND c.table_name <> 'schema_migrari'
        AND c.data_type IN ('timestamp with time zone', 'timestamp without time zone', 'date')`,
  );
  const peTabele = new Map<string, string[]>();
  for (const c of coloane) peTabele.set(c.tabel, [...(peTabele.get(c.tabel) ?? []), c.coloana]);
  await db.tx(async (t) => {
    // Zilele se adună în ora Chișinăului, ca orele din istoric să rămână aceleași și peste schimbarea orei.
    await t.exec(`SET LOCAL TimeZone = 'Europe/Chisinau'`);
    // Registrele (mișcări de stoc și bani, jurnalul de audit) nu se modifică: declanșatorii lor le apără.
    // Doar aici, la mutarea în bloc a datelor demo, ei se ocolesc pentru această tranzacție.
    await t.exec(`SET LOCAL session_replication_role = replica`);
    for (const [tabel, cols] of peTabele) {
      await t.query(`UPDATE ${tabel} SET ${cols.map((c) => `${c} = ${c} + $1::interval`).join(', ')}`, [`${zile} days`]);
    }
  });
  await scrieSetare(db, CHEIE_SIMULARE, { generat_pentru: azi });
}

async function asociaza(db: Db, nume: string): Promise<TabletaSim> {
  const [d] = await db.query<{ id: number }>('SELECT id FROM dispozitive WHERE nume = $1', [nume]);
  const { cod_asociere } = await acces.reasociazaDispozitiv(db, d.id);
  return acces.asociazaDispozitiv(db, cod_asociere);
}

const citesteLocal = (cheie: string) => {
  try {
    return localStorage.getItem(cheie);
  } catch {
    return null;
  }
};
const scrieLocal = (cheie: string, valoare: string | null) => {
  try {
    if (valoare === null) localStorage.removeItem(cheie);
    else localStorage.setItem(cheie, valoare);
  } catch {
    /* stocare blocată: previzualizarea pornește de la zero data viitoare */
  }
};

/** Șterge baza păstrată a previzualizării, ca data viitoare să pornească de la zero. */
export async function stergeDatePastrate(persistenta: string) {
  scrieLocal(`${persistenta}:tablete`, null);
  await new Promise<void>((gata) => {
    const r = indexedDB.deleteDatabase(`/pglite/${persistenta}`);
    r.onsuccess = r.onerror = r.onblocked = () => gata();
  });
}

export async function pornesteServer(laProgres: (p: Progres) => void, opt: OptiuniServer = {}): Promise<ServerSim> {
  const cheieTablete = opt.persistenta ? `${opt.persistenta}:tablete` : null;
  const tabletePastrate = cheieTablete ? (JSON.parse(citesteLocal(cheieTablete) ?? 'null') as { centru: TabletaSim; botanica: TabletaSim } | null) : null;
  const proaspat = !tabletePastrate;
  // Cele trei fișiere mari se descarcă în paralel; progresul e suma lor. Arhiva lipsește când baza e deja în browser.
  const surse = [urlWasm, new URL('pglite-fs.txt', bazaModul).href, ...(proaspat ? [new URL(opt.arhiva ?? 'date-demo.txt', bazaModul).href] : [])];
  const primiti = surse.map(() => 0);
  const totaluri = surse.map(() => 0);
  const raporteaza = () => {
    const total = totaluri.reduce((s, x) => s + x, 0);
    const p = total ? primiti.reduce((s, x) => s + x, 0) / total : 0;
    laProgres({ faza: `Se descarcă programul și datele (${(primiti.reduce((s, x) => s + x, 0) / 1e6).toFixed(1)} MB)`, procent: Math.min(0.85, p * 0.85) });
  };
  const [wasm, fsText, arhivaText = new Uint8Array()] = await Promise.all(
    surse.map((u, i) =>
      descarca(u, (n, t) => {
        primiti[i] = n;
        totaluri[i] = t || n;
        raporteaza();
      }),
    ),
  );

  laProgres({ faza: 'Pornește baza de date (PostgreSQL în browser)', procent: 0.88 });
  const fs = await dezarhiveaza(dinBase64(fsText));
  const wasmModule = await WebAssembly.compile(wasm);
  if (proaspat && opt.persistenta) await stergeDatePastrate(opt.persistenta);
  const lite = await PGlite.create({
    wasmModule,
    fsBundle: new Blob([fs]),
    ...(opt.persistenta ? { dataDir: `idb://${opt.persistenta}` } : {}),
    ...(proaspat ? { loadDataDir: new Blob([dinBase64(arhivaText)], { type: 'application/x-gzip' }) } : {}),
    parsers: { [types.NUMERIC]: parseFloat, [types.INT8]: Number },
  });
  const db = dinPglite(lite);
  await aplicaMigrari(db);

  laProgres({ faza: 'Pregătește rețeaua de cafenele', procent: 0.94 });
  // Istoricul demo se aduce la zi doar la încărcarea arhivei; datele păstrate ale previzualizării sunt reale.
  if (proaspat) await aduceIstoriculLaZi(db);
  // Parola panoului rămâne „schimba-ma”; hash-ul se reface cu înlocuitorul de scrypt din browser.
  for (const u of await db.query<{ id: number; sare: string }>(`SELECT id, sare FROM utilizatori WHERE login = 'admin'`)) {
    await db.query('UPDATE utilizatori SET parola_hash = $2 WHERE id = $1', [u.id, await acces.hashParola('schimba-ma', u.sare)]);
  }
  const { token: tokenAdmin } = await acces.autentificare(db, 'admin', 'schimba-ma');
  const [{ nume: numeTableta }] = await db.query<{ nume: string }>(`SELECT nume FROM dispozitive WHERE nume LIKE 'Tabletă%' AND nume <> 'Tabletă Botanica' ORDER BY id LIMIT 1`);
  const centru = tabletePastrate?.centru ?? (await asociaza(db, numeTableta));
  const botanica = tabletePastrate?.botanica ?? (await asociaza(db, 'Tabletă Botanica'));
  if (cheieTablete && proaspat) scrieLocal(cheieTablete, JSON.stringify({ centru, botanica }));

  const terminal = new TerminalSimulat();
  if (opt.terminalSimulat !== false) folosesteClientPOSLink(new ClientPOSLink({ url: 'https://poslink.simulare/POSLink', cheie: 'simulare' }, terminal.fetch));

  // Aceleași reguli de acces ca în server/src/app.ts.
  const tokenDin = (req: CerereSim) => {
    const h = req.headers.authorization;
    return h?.startsWith('Bearer ') ? h.slice(7) : null;
  };
  const doarAdmin = async (req: CerereSim, reply: RaspunsSim) => {
    const token = tokenDin(req);
    const u = token ? await acces.utilizatorDinToken(db, token) : null;
    if (!u || u.rol !== 'admin') return reply.status(401).send({ eroare: 'Autentificare necesară' });
    req.utilizator = u;
  };
  const doarDispozitiv = async (req: CerereSim, reply: RaspunsSim) => {
    const token = tokenDin(req);
    const d = token ? await acces.dispozitivDinToken(db, token) : null;
    if (!d) return reply.status(401).send({ eroare: 'Tableta nu este asociată sau a fost dezactivată' });
    req.dispozitiv = d;
  };

  const ruter = new RuterSim();
  const app = ruter.instanta();
  // Ca în server/src/app.ts: verificarea de sănătate atinge și baza.
  app.get('/api/sanatate', async (_req: any, reply: any) =>
    (await bazaRaspunde(db, 2_000)) ? { ok: true, ora: new Date().toISOString() } : reply.status(503).send({ ok: false, eroare: 'Baza de date nu răspunde' }),
  );
  app.post('/api/flux/bilet', async (req: any, reply: any) => {
    const token = tokenDin(req);
    const u = token ? await acces.utilizatorDinToken(db, token) : null;
    const d = !u && token ? await acces.dispozitivDinToken(db, token) : null;
    if (!u && !d) return reply.status(401).send({ eroare: 'Autentificare necesară' });
    return { bilet: acces.creeazaBilet(u ? { utilizator: u } : { dispozitiv: d! }, token!) };
  });
  await app.register(async (pos) => rutePOS(pos, db, doarDispozitiv as any));
  await app.register(async (adm) => ruteAdmin(adm, db, doarAdmin as any));
  await ruter.gata();

  const flux = (bilet: string, laMesaj: (date: string) => void) => {
    const detinator = acces.detinatorBilet(bilet);
    if (!detinator) return null;
    const d = detinator.dispozitiv ?? null;
    const asculta = (n: Notificare) => {
      if (d && n.locatie_id != null && n.locatie_id !== d.locatie_id) return;
      laMesaj(JSON.stringify(n));
    };
    magistrala.on('notificare', asculta);
    // Ca în server/src/app.ts: la fiecare puls fluxul se reverifică (ieșire, tabletă dezactivată sau reasociată).
    let oprit = false;
    const opreste = () => {
      oprit = true;
      clearInterval(puls);
      magistrala.off('notificare', asculta);
    };
    const puls = setInterval(() => {
      void acces.detinatorValid(db, detinator).then((valid) => {
        if (!valid && !oprit) opreste();
      }, () => {});
    }, 25_000);
    return opreste;
  };

  laProgres({ faza: 'Gata', procent: 1 });
  return { db, ruter, terminal, tokenAdmin, centru, botanica, proaspat, flux };
}
